step1 = create and post file there => project/wp-content/plugins/person-api.php
step2 = create and post file there => project/wp-content/plugins/posts-api.php
step3 = create and post file there => project/wp-content/plugins/student-api.php

step4 = active plugin
step5 = run api using postman
